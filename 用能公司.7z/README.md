# 微信小程序-前端 [开发版]

#### 内部原创组件说明
>`Toast` 组件: [查看 说明/源码](https://gitee.com/slm47888/wechat_applet__component_toast)